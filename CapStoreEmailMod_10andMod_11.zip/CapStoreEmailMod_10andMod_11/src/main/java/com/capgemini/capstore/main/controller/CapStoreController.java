package com.capgemini.capstore.main.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Email;
import com.capgemini.capstore.main.service.CapStoreEmailService;

@RestController
public class CapStoreController {

	@Autowired
	private CapStoreEmailService capStoreEmailService;

	/*@RequestMapping(method = RequestMethod.GET, value = "/generateNewEmail")
	public Email generateNewEmail() throws IOException {
		return capStoreEmailService.generateNewEmail("xyz@gmail.com", "Customer");
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/generateVerifiedEmail")
	public Email generateVerifiedEmail() throws IOException {
		return capStoreEmailService.generateVerifiedEmail("xyz@gmail.com", "Customer");
	}
*/
	@RequestMapping(method = RequestMethod.GET, value = "/validateEmail")
	public Email validateEmail() throws IOException {
		return capStoreEmailService.validateEmail("xyz@gmail.com", "Customer");
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/afterVerificationEmail")
	public boolean afterVerificationEmail() throws IOException {
		return capStoreEmailService.afterVerification("xyz@gmail.com","11519","Customer");
	}
	
}
