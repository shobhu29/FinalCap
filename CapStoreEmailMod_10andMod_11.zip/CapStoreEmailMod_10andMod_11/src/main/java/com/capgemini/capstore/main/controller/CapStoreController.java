package com.capgemini.capstore.main.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Email;
import com.capgemini.capstore.main.service.CapStoreEmailService;

@RestController
public class CapStoreController {

	@Autowired
	private CapStoreEmailService capStoreEmailService;

	/*@RequestMapping(method = RequestMethod.GET, value = "/generateNewEmail")
	public Email generateNewEmail() throws IOException {
		return capStoreEmailService.generateNewEmail("xyz@gmail.com", "Customer");
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/generateVerifiedEmail")
	public Email generateVerifiedEmail() throws IOException {
		return capStoreEmailService.generateVerifiedEmail("xyz@gmail.com", "Customer");
	}
*/
	@RequestMapping(method = RequestMethod.GET, value = "/validateEmail/{receiverEmailId}/{receiverRole}")
	public Email validateEmail(@PathVariable String receiverEmailId,@PathVariable String receiverRole) throws IOException {
		return capStoreEmailService.validateEmail(receiverEmailId, receiverRole);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/afterVerificationEmail/{receiverEmailId}/{otpNumber}/{receiverRole}")
	public boolean afterVerificationEmail(@PathVariable String receiverEmailId,@PathVariable String otpNumber,@PathVariable String receiverRole) throws IOException {
		return capStoreEmailService.afterVerification(receiverEmailId,otpNumber,receiverRole);
	}
	
}
